import 'dart:convert';
import 'package:http/http.dart' as http;

class BackendService {
  static const String baseUrl =
      "http://127.0.0.1:5000"; // Replace with your Flask server URL

  /// =======================
  /// Authentication
  /// =======================

  /// Login endpoint
  static Future<Map<String, dynamic>> login(String id, String password) async {
    final response = await http.post(
      Uri.parse("$baseUrl/login"),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'id': id, 'password': password}),
    );

    return jsonDecode(response.body);
  }

  /// Signup endpoint (new)
  static Future<Map<String, dynamic>> signUp(
      String id, String password, String role) async {
    final response = await http.post(
      Uri.parse("$baseUrl/signup"),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'id': id, 'password': password, 'role': role}),
    );

    return jsonDecode(response.body);
  }

  /// =======================
  /// Exams
  /// =======================

  static Future<List<dynamic>> getExams() async {
    final response = await http.get(Uri.parse("$baseUrl/get_exams"));
    final data = jsonDecode(response.body);
    return data; // List<dynamic>
  }

  static Future<List<dynamic>> getQuestions(String examId) async {
    final response =
        await http.get(Uri.parse("$baseUrl/get_questions/$examId"));
    final data = jsonDecode(response.body);
    return data; // List<dynamic>
  }

  static Future<void> submitExam(
      String studentName, String examId, Map<String, String> answers) async {
    await http.post(
      Uri.parse("$baseUrl/submit_exam"),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'studentName': studentName,
        'examId': examId,
        'answers': answers,
      }),
    );
  }

  /// =========================
  /// Student Exam Monitoring
  /// =========================

  static Future<String> monitorFrame(
      String studentName, String examId, String imagePath) async {
    var request =
        http.MultipartRequest('POST', Uri.parse("$baseUrl/monitor_frame"));
    request.fields['studentName'] = studentName;
    request.fields['examId'] = examId;
    request.files.add(await http.MultipartFile.fromPath('frame', imagePath));

    var response = await request.send();
    var respStr = await response.stream.bytesToString();
    final data = jsonDecode(respStr);

    return data['warning'] ?? ""; // returns warning message if any
  }

  /// =========================
  /// Teacher Live Monitoring
  /// =========================

  static Future<List<dynamic>> getMonitorAlerts(String examId) async {
    final response = await http.get(Uri.parse("$baseUrl/get_warnings/$examId"));
    final data = jsonDecode(response.body);
    return data; // List<dynamic> of {studentName, message, count}
  }

  static Future<void> autoSubmitExam(String examId, String studentName) async {
    await http.post(
      Uri.parse("$baseUrl/auto_submit"),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'examId': examId, 'studentName': studentName}),
    );
  }
}
