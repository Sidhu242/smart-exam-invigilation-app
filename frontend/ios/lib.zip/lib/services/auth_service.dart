import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/user.dart';

class AuthService {
  static const String baseUrl = "http://127.0.0.1:5000";

  static Future<User?> login(String id, String password, String role) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/login'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"id": id, "password": password, "role": role}),
      );

      if (response.statusCode == 200) {
        return User(id: id, role: role);
      } else {
        return null;
      }
    } catch (e) {
      print("Login Error: $e");
      return null;
    }
  }
}
