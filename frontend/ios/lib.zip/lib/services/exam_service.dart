import '../models/exam.dart';

class ExamService {
  static List<Exam> getScheduledExams(String studentId) {
    return [
      Exam(
        id: "e1",
        title: "Math Exam",
        date: "2025-10-21",
        time: "10:00 AM",
        questions: generateQuestions(),
      ),
      Exam(
        id: "e2",
        title: "Physics Exam",
        date: "2025-10-22",
        time: "2:00 PM",
        questions: generateQuestions(),
      ),
    ];
  }

  static List<Question> generateQuestions() {
    List<Question> questions = [];
    for (int i = 1; i <= 10; i++) {
      questions.add(
        Question(
          question: "Question $i: What is ${i} + ${i}?",
          options: ["${i}", "${i * 2}", "${i + 3}", "${i - 1}"],
          correctIndex: 1,
        ),
      );
    }
    return questions;
  }
}
