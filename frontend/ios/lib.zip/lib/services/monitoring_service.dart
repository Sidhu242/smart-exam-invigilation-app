import 'dart:io';
import 'package:http/http.dart' as http;

class MonitoringService {
  static Future<void> sendCameraFrame(
      String studentName, String examId, String imagePath) async {
    final uri = Uri.parse("http://YOUR_SERVER_IP:5000/upload_frame");
    var request = http.MultipartRequest('POST', uri)
      ..fields['student'] = studentName
      ..fields['exam_id'] = examId
      ..files.add(await http.MultipartFile.fromPath('frame', imagePath));

    try {
      await request.send();
    } catch (e) {
      print("Failed to send frame: $e");
    }
  }

  static Future<void> sendAudioChunk(
      String studentName, String examId, List<int> audioBytes) async {
    // TODO: send audio bytes to backend
  }

  static Future<List<Map<String, String>>> getWarnings(String examId) async {
    // TODO: fetch warnings for teacher dashboard
    return [];
  }
}
