import 'dart:async';
import 'package:flutter/material.dart';
import 'pages/login_page.dart'; // adjust if LoginPage is in a different path

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _animController;
  late final Animation<double> _fadeAnim;

  // Duration the splash is visible before navigation
  static const Duration splashDuration = Duration(seconds: 2);
  // Fade in duration for the logo
  static const Duration fadeDuration = Duration(milliseconds: 700);

  @override
  void initState() {
    super.initState();

    // Setup fade animation for the logo
    _animController = AnimationController(vsync: this, duration: fadeDuration);
    _fadeAnim =
        CurvedAnimation(parent: _animController, curve: Curves.easeInOut);

    // Precache image so it appears without flicker
    WidgetsBinding.instance.addPostFrameCallback((_) {
      precacheImage(const AssetImage('assets/logo/siesaura.png'), context)
          .then((_) {
        _animController.forward(); // start fade-in once cached
      });
    });

    // Navigate after the splash duration
    Future.delayed(splashDuration, () {
      Navigator.of(context).pushReplacement(PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 600),
        pageBuilder: (_, animation, __) =>
            FadeTransition(opacity: animation, child: const LoginPage()),
      ));
    });
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Use safe area + centered layout so it works on all screens
    return Scaffold(
      backgroundColor:
          Colors.white, // change if you want a different background
      body: SafeArea(
        child: Center(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: Image.asset(
              'assets/logo/siesaura.png',
              width: MediaQuery.of(context).size.width * 0.6, // responsive size
              fit: BoxFit.contain,
            ),
          ),
        ),
      ),
    );
  }
}
