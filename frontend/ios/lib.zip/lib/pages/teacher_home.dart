// lib/teacher_home.dart
import 'package:flutter/material.dart';
import 'schedule_exam.dart';
import 'live_monitoring.dart';
import 'manage_exams_page.dart';
import 'global.dart' as globals;

class TeacherHomePage extends StatefulWidget {
  final String teacherName;

  const TeacherHomePage({
    Key? key,
    required this.teacherName,
  }) : super(key: key);

  @override
  State<TeacherHomePage> createState() => _TeacherHomePageState();
}

class _TeacherHomePageState extends State<TeacherHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F0FA),
      appBar: AppBar(
        title: Text('Teacher Dashboard - ${globals.globalInstitution}'),
        backgroundColor: const Color(0xFF673AB7),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Welcome, ${widget.teacherName}! 👨‍🏫",
              style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: Color(0xFF512DA8),
              ),
            ),

            const SizedBox(height: 30),

            // CREATE EXAM
            _buildDashboardCard(
              icon: Icons.add_task_rounded,
              title: "Create New Exam",
              subtitle: "Schedule exams & add questions",
              color: Colors.deepPurple,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const ScheduleExamPage(),
                  ),
                );
              },
            ),

            const SizedBox(height: 20),

            // LIVE MONITORING
            _buildDashboardCard(
              icon: Icons.videocam_outlined,
              title: "Live Exam Monitoring",
              subtitle: "Track students with AI proctoring",
              color: Colors.orange,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => LiveMonitoringPage(
                      examId: '',
                      institution: globals.globalInstitution,
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 20),

            // MANAGE EXAMS
            _buildDashboardCard(
              icon: Icons.manage_accounts,
              title: "Manage Exams",
              subtitle: "View / Publish / Delete exams",
              color: Colors.teal,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ManageExamPage(
                      teacherName: widget.teacherName,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDashboardCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.90),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              blurRadius: 20,
              offset: const Offset(0, 6),
              color: Colors.deepPurple.withOpacity(0.15),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 30, color: color),
            ),
            const SizedBox(width: 18),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF311B92),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios_rounded, size: 22),
          ],
        ),
      ),
    );
  }
}
