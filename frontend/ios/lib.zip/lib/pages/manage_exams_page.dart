// lib/manage_exam_page.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'global.dart' as globals;
import 'schedule_exam.dart';
import 'add_question_page.dart';
import 'results_page.dart';

class ManageExamPage extends StatefulWidget {
  final String teacherName;
  const ManageExamPage({Key? key, required this.teacherName}) : super(key: key);

  @override
  State<ManageExamPage> createState() => _ManageExamPageState();
}

class _ManageExamPageState extends State<ManageExamPage> {
  List _exams = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchExams();
  }

  Future<void> _fetchExams() async {
    setState(() => _isLoading = true);
    try {
      var url = Uri.parse(
          '${globals.SERVER}/get_exams?institution=${Uri.encodeComponent(globals.globalInstitution)}');
      var response = await http.get(url);
      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        setState(() => _exams = data['exams'] ?? []);
      }
    } catch (e) {}
    setState(() => _isLoading = false);
  }

  void _openOptions(Map exam) {
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return SafeArea(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              ListTile(
                  leading: const Icon(Icons.add),
                  title: const Text('Add Questions'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => AddQuestionPage(
                                examId: exam['id'], examName: exam['name'])));
                  }),
              ListTile(
                  leading: const Icon(Icons.bar_chart),
                  title: const Text('View Results'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => ResultsPage(
                                institution: globals.globalInstitution,
                                examId: exam['id'])));
                  }),
              ListTile(
                  leading: const Icon(Icons.publish),
                  title: const Text('Publish Exam'),
                  onTap: () async {
                    Navigator.pop(context);
                    await _publishExam(exam['id']);
                    _fetchExams();
                  }),
              ListTile(
                  leading: const Icon(Icons.delete_forever, color: Colors.red),
                  title: const Text('Delete Exam',
                      style: TextStyle(color: Colors.red)),
                  onTap: () async {
                    Navigator.pop(context);
                    await _deleteExam(exam['id']);
                    _fetchExams();
                  }),
            ]),
          );
        });
  }

  Future<void> _publishExam(String examId) async {
    try {
      var url = Uri.parse('${globals.SERVER}/publish_exam');
      await http.post(url,
          headers: {'Content-Type': 'application/json; charset=UTF-8'},
          body: jsonEncode({'exam_id': examId}));
    } catch (e) {}
  }

  Future<void> _deleteExam(String examId) async {
    try {
      var url = Uri.parse('${globals.SERVER}/delete_exam/$examId');
      await http.delete(url);
    } catch (e) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text('Manage Exams - ${globals.globalInstitution}'),
          backgroundColor: const Color(0xFF673AB7)),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: _exams.length,
              itemBuilder: (context, idx) {
                var exam = _exams[idx];
                return Card(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: ListTile(
                    title: Text(exam['name'] ?? 'No name'),
                    subtitle: Text(
                        'ID: ${exam['id']} • ${exam['exam_datetime'] ?? exam['time'] ?? 'TBD'}'),
                    trailing: IconButton(
                        icon: const Icon(Icons.more_vert),
                        onPressed: () => _openOptions(exam)),
                  ),
                );
              },
            ),
    );
  }
}
