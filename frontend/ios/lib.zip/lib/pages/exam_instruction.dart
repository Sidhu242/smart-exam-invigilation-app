// lib/exam_instruction.dart
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'exam_page.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

class ExamInstructionPage extends StatelessWidget {
  final String studentId;
  final String examId;
  final String examName;

  const ExamInstructionPage(
      {Key? key,
      required this.studentId,
      required this.examId,
      required this.examName})
      : super(key: key);

  Future<void> requestPermissionsAndStart(BuildContext context) async {
    bool cameraGranted = true;
    bool micGranted = true;

    if (!kIsWeb) {
      var permissions =
          await [Permission.camera, Permission.microphone].request();
      cameraGranted = permissions[Permission.camera]?.isGranted ?? false;
      micGranted = permissions[Permission.microphone]?.isGranted ?? false;
    }

    if (!context.mounted) return;

    if (cameraGranted && micGranted) {
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => ExamPage(
                  examId: examId, examName: examName, studentId: studentId)));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text(
              'Camera and Microphone permissions are required to start the exam.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: const Text('Exam Instructions')),
        body: Padding(
            padding: const EdgeInsets.all(16),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Exam: $examName',
                  style: Theme.of(context)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              Text('Rules & Instructions:',
                  style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 10),
              const Text(
                  '1. You must remain in front of the camera at all times.'),
              const Text('2. No other people are allowed in the room.'),
              const Text('3. Do not use your phone or other websites.'),
              const Text('4. Your camera and microphone will be monitored.'),
              const SizedBox(height: 10),
              const Text(
                  'This exam is proctored by an AI. Any suspicious activity will be flagged and reported to your teacher.'),
              const Spacer(),
              ElevatedButton(
                  onPressed: () => requestPermissionsAndStart(context),
                  style: ElevatedButton.styleFrom(
                      minimumSize: const Size(double.infinity, 50)),
                  child: const Text('I Understand and I am Ready to Start')),
              const SizedBox(height: 20)
            ])));
  }
}
