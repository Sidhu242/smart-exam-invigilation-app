// students_list_page.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

const SERVER = 'http://localhost:5000';

class StudentsListPage extends StatefulWidget {
  final String institution;
  const StudentsListPage({Key? key, required this.institution})
      : super(key: key);

  @override
  State<StudentsListPage> createState() => _StudentsListPageState();
}

class _StudentsListPageState extends State<StudentsListPage> {
  List _students = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _fetchStudents();
  }

  Future<void> _fetchStudents() async {
    setState(() => _loading = true);
    try {
      final url = Uri.parse(
          '$SERVER/get_students/${Uri.encodeComponent(widget.institution)}');
      final res = await http.get(url);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        setState(() {
          _students = data['students'] ?? [];
        });
      }
    } catch (e) {
      // ignore
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<Map?> _getStudentStats(String studentId) async {
    try {
      final url = Uri.parse('$SERVER/get_student_stats/$studentId');
      final res = await http.get(url);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        return data['stats'];
      }
    } catch (e) {}
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Students — ${widget.institution}'),
        backgroundColor: Color(0xFF673AB7),
      ),
      body: RefreshIndicator(
        onRefresh: _fetchStudents,
        child: _loading
            ? Center(child: CircularProgressIndicator(color: Color(0xFF673AB7)))
            : _students.isEmpty
                ? Center(child: Text('No students found'))
                : ListView.builder(
                    padding: EdgeInsets.all(12),
                    itemCount: _students.length,
                    itemBuilder: (_, i) {
                      final s = _students[i];
                      return ListTile(
                        leading: CircleAvatar(
                            child: Text(s['id']
                                .toString()
                                .substring(0, 1)
                                .toUpperCase())),
                        title: Text(s['name'] ?? s['id']),
                        subtitle: Text('ID: ${s['id']}'),
                        trailing: IconButton(
                          icon: Icon(Icons.info_outline),
                          onPressed: () async {
                            final stats = await _getStudentStats(s['id']);
                            showModalBottomSheet(
                                context: context,
                                builder: (_) {
                                  return Container(
                                    padding: EdgeInsets.all(16),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(s['name'] ?? s['id'],
                                              style: TextStyle(
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.bold)),
                                          SizedBox(height: 8),
                                          Text(
                                              'Completed exams: ${stats?['completed_exams'] ?? 'N/A'}'),
                                          Text(
                                              'Warnings: ${stats?['warnings'] ?? 'N/A'}'),
                                          Text(
                                              'Accuracy: ${stats?['accuracy'] != null ? stats!['accuracy'].toString() + "%" : "N/A"}'),
                                        ]),
                                  );
                                });
                          },
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}
