// lib/schedule_exam.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'add_question_page.dart';
import 'global.dart' as globals;

class ScheduleExamPage extends StatefulWidget {
  const ScheduleExamPage({Key? key}) : super(key: key);

  @override
  State<ScheduleExamPage> createState() => _ScheduleExamPageState();
}

class _ScheduleExamPageState extends State<ScheduleExamPage> {
  final _formKey = GlobalKey<FormState>();
  final _examIdController = TextEditingController();
  final _examNameController = TextEditingController();
  final _examTimeController = TextEditingController();
  final _examDateTimeController = TextEditingController();
  String _message = '';

  @override
  void dispose() {
    _examIdController.dispose();
    _examNameController.dispose();
    _examTimeController.dispose();
    _examDateTimeController.dispose();
    super.dispose();
  }

  Future<void> _createExam() async {
    if (_formKey.currentState?.validate() != true) return;

    var url = Uri.parse('${globals.SERVER}/create_exam');

    try {
      var response = await http.post(url,
          headers: {'Content-Type': 'application/json; charset=UTF-8'},
          body: jsonEncode({
            'id': _examIdController.text.trim(),
            'name': _examNameController.text.trim(),
            'time': _examTimeController.text.trim(),
            'institution': globals.globalInstitution,
            'exam_datetime': _examDateTimeController.text.trim(),
          }));

      var data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['status'] == 'success') {
        setState(() => _message = 'Exam created! Add questions now.');
        String examId = _examIdController.text.trim();
        String examName = _examNameController.text.trim();
        _formKey.currentState?.reset();
        _examIdController.clear();
        _examNameController.clear();
        _examTimeController.clear();
        _examDateTimeController.clear();

        // Navigate to AddQuestionPage with examId/examName
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    AddQuestionPage(examId: examId, examName: examName)));
      } else {
        setState(() => _message = data['message'] ?? 'Error creating exam.');
      }
    } catch (e) {
      setState(() => _message = 'Error: Could not connect to server.');
    }
  }

  Widget _buildTextField(TextEditingController controller, String label) {
    return TextFormField(
        controller: controller,
        validator: (v) => v == null || v.isEmpty ? "Required" : null,
        decoration: InputDecoration(
            labelText: label,
            filled: true,
            fillColor: const Color(0xFFF3EFFF),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F0FA),
      appBar: AppBar(
          title: const Text("Create New Exam"),
          backgroundColor: const Color(0xFF673AB7),
          elevation: 0),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(18),
        child: Container(
          padding: const EdgeInsets.all(26),
          decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.88),
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(
                    color: Colors.deepPurple.withOpacity(0.18),
                    blurRadius: 22,
                    offset: const Offset(0, 6))
              ]),
          child: Form(
            key: _formKey,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text("Schedule an Exam",
                      style: TextStyle(
                          fontSize: 22,
                          color: Color(0xFF512DA8),
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 18),
                  _buildTextField(_examIdController, "Exam ID (e.g. e2)"),
                  const SizedBox(height: 12),
                  _buildTextField(_examNameController, "Exam Name"),
                  const SizedBox(height: 12),
                  _buildTextField(_examTimeController, "Exam Time (11:00 AM)"),
                  const SizedBox(height: 12),
                  TextFormField(
                      controller: _examDateTimeController,
                      decoration: InputDecoration(
                          labelText: "Exam DateTime (YYYY-MM-DD HH:MM)",
                          filled: true,
                          fillColor: const Color(0xFFF3EFFF),
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide: BorderSide.none))),
                  const SizedBox(height: 22),
                  ElevatedButton(
                      onPressed: _createExam,
                      style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF673AB7),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12))),
                      child: const Text("Create & Add Questions")),
                  const SizedBox(height: 12),
                  if (_message.isNotEmpty)
                    Text(_message,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: _message.contains('created')
                                ? Colors.green
                                : Colors.red)),
                ]),
          ),
        ),
      ),
    );
  }
}
