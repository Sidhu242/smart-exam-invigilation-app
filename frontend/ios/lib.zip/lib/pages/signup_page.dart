// lib/signup_page.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'global.dart' as globals;

class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final _idController = TextEditingController();
  final _nameController = TextEditingController();
  final _passwordController = TextEditingController();
  final _repeatPasswordController = TextEditingController();

  String _selectedRole = 'student';
  String _selectedInstitution = 'Jain University';
  String _message = '';

  final List<String> _institutions = [
    'Jain University',
    'RV College',
    'Christ University',
    'Other'
  ];

  @override
  void dispose() {
    _idController.dispose();
    _nameController.dispose();
    _passwordController.dispose();
    _repeatPasswordController.dispose();
    super.dispose();
  }

  Future<void> _signupUser() async {
    if (_passwordController.text != _repeatPasswordController.text) {
      setState(() => _message = "Passwords do not match");
      return;
    }

    String id = _idController.text.trim();
    String name = _nameController.text.trim();
    String password = _passwordController.text.trim();
    String role = _selectedRole;
    String institution = _selectedInstitution;

    if (id.isEmpty || name.isEmpty || password.isEmpty) {
      setState(() => _message = "Please fill all fields");
      return;
    }

    var url = Uri.parse('${globals.SERVER}/signup');
    try {
      var response = await http.post(url,
          headers: {'Content-Type': 'application/json; charset=UTF-8'},
          body: jsonEncode({
            'id': id,
            'name': name,
            'password': password,
            'role': role,
            'institution': institution,
          }));

      var data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['status'] == 'success') {
        setState(() {
          _message = "Signup successful! You can now login.";
        });
        // Optionally navigate back to login
      } else {
        setState(() => _message = data['message'] ?? 'Error during signup');
      }
    } catch (e) {
      setState(() => _message = "Error: Could not connect to server.");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('Create Account'),
          elevation: 0,
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.black),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(28),
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.95),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 18)]),
            child: Column(children: [
              const Text('Create Account',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              const SizedBox(height: 18),
              TextField(
                  controller: _idController,
                  decoration: InputDecoration(
                      labelText: 'ID (Student or Teacher)',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12)))),
              const SizedBox(height: 12),
              TextField(
                  controller: _nameController,
                  decoration: InputDecoration(
                      labelText: 'Full Name',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12)))),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _selectedRole,
                decoration: InputDecoration(
                    labelText: 'Role',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12))),
                items: const [
                  DropdownMenuItem(value: 'student', child: Text('Student')),
                  DropdownMenuItem(value: 'teacher', child: Text('Teacher')),
                ],
                onChanged: (v) => setState(() => _selectedRole = v!),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _selectedInstitution,
                decoration: InputDecoration(
                    labelText: 'Institution',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12))),
                items: _institutions
                    .map((i) => DropdownMenuItem(value: i, child: Text(i)))
                    .toList(),
                onChanged: (v) => setState(() => _selectedInstitution = v!),
              ),
              const SizedBox(height: 12),
              TextField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                      labelText: 'Password',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12)))),
              const SizedBox(height: 12),
              TextField(
                  controller: _repeatPasswordController,
                  obscureText: true,
                  decoration: InputDecoration(
                      labelText: 'Repeat Password',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12)))),
              const SizedBox(height: 18),
              ElevatedButton(
                  onPressed: _signupUser,
                  style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF673AB7),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12))),
                  child: const Text('Submit')),
              const SizedBox(height: 12),
              if (_message.isNotEmpty)
                Text(_message,
                    style: TextStyle(
                        color: _message.contains('successful')
                            ? Colors.green
                            : Colors.red)),
            ]),
          ),
        ),
      ),
    );
  }
}
