// lib/results_page.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'global.dart' as globals;

class ResultsPage extends StatefulWidget {
  final String institution;
  final String examId;
  const ResultsPage({Key? key, required this.institution, required this.examId})
      : super(key: key);

  @override
  State<ResultsPage> createState() => _ResultsPageState();
}

class _ResultsPageState extends State<ResultsPage> {
  List _results = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchResults();
  }

  Future<void> _fetchResults() async {
    try {
      var url =
          Uri.parse('${globals.SERVER}/get_exam_results/${widget.examId}');
      var response = await http.get(url);
      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        setState(() => _results = data['results'] ?? []);
      }
    } catch (e) {}
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            title: Text('Results - ${widget.examId}'),
            backgroundColor: const Color(0xFF673AB7)),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : ListView.builder(
                itemCount: _results.length,
                itemBuilder: (context, idx) {
                  var r = _results[idx];
                  return ListTile(
                      title: Text(r['student_name'] ?? r['student_id']),
                      subtitle: Text(
                          'Answers: ${r['answers_count'] ?? '-'} • Warnings: ${r['warnings'] ?? 0}'));
                }));
  }
}
