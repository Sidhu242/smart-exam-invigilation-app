// lib/student_home.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'global.dart' as globals;
import 'exam_instruction.dart';

class StudentHomePage extends StatefulWidget {
  final String studentName;
  final String studentId;

  const StudentHomePage(
      {Key? key, required this.studentName, required this.studentId})
      : super(key: key);

  @override
  State<StudentHomePage> createState() => _StudentHomePageState();
}

class _StudentHomePageState extends State<StudentHomePage> {
  bool _isLoading = true;
  List _exams = [];
  Map<String, dynamic>? _summary;
  List _announcements = [];
  List _calendar = [];
  List _leaderboard = [];
  Timer? _summaryTimer;
  Timer? _announcementsTimer;
  String _search = '';
  String _tab = 'upcoming';

  @override
  void initState() {
    super.initState();
    _refreshAll();
    _summaryTimer =
        Timer.periodic(const Duration(seconds: 8), (_) => _fetchSummary());
    _announcementsTimer = Timer.periodic(
        const Duration(seconds: 8), (_) => _fetchAnnouncements());
  }

  @override
  void dispose() {
    _summaryTimer?.cancel();
    _announcementsTimer?.cancel();
    super.dispose();
  }

  Future<void> _refreshAll() async {
    setState(() => _isLoading = true);
    await Future.wait([
      _fetchExams(),
      _fetchSummary(),
      _fetchAnnouncements(),
      _fetchCalendar(),
      _fetchLeaderboard()
    ]);
    setState(() => _isLoading = false);
  }

  Future<void> _fetchExams() async {
    try {
      var url = Uri.parse(
          '${globals.SERVER}/get_exams?institution=${Uri.encodeComponent(globals.globalInstitution)}');
      var response = await http.get(url);
      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        setState(() => _exams = data['exams'] ?? []);
      }
    } catch (e) {}
  }

  Future<void> _fetchSummary() async {
    try {
      var url = Uri.parse('${globals.SERVER}/get_summary/${widget.studentId}');
      var response = await http.get(url);
      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        setState(() => _summary = data['summary']);
      }
    } catch (e) {}
  }

  Future<void> _fetchAnnouncements() async {
    try {
      var url = Uri.parse(
          '${globals.SERVER}/get_announcements/${Uri.encodeComponent(globals.globalInstitution)}');
      var response = await http.get(url);
      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        setState(() => _announcements = data['announcements']);
      }
    } catch (e) {}
  }

  Future<void> _fetchCalendar() async {
    try {
      var url = Uri.parse('${globals.SERVER}/get_calendar/${widget.studentId}');
      var response = await http.get(url);
      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        setState(() => _calendar = data['calendar']);
      }
    } catch (e) {}
  }

  Future<void> _fetchLeaderboard() async {
    try {
      var url = Uri.parse(
          '${globals.SERVER}/leaderboard/${Uri.encodeComponent(globals.globalInstitution)}');
      var response = await http.get(url);
      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        setState(() => _leaderboard = data['leaderboard']);
      }
    } catch (e) {}
  }

  void _startExam(String examId, String examName) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => ExamInstructionPage(
                examId: examId,
                examName: examName,
                studentId: widget.studentId)));
  }

  List _filteredExams() {
    List list = _exams;
    if (_search.isNotEmpty) {
      list = list
          .where((e) => (e['name'] ?? '')
              .toString()
              .toLowerCase()
              .contains(_search.toLowerCase()))
          .toList();
    }
    if (_tab == 'upcoming') {
      list = list
          .where((e) => e['exam_datetime'] != null || (e['time'] != null))
          .toList();
    } else if (_tab == 'completed') {
      // simplistic: rely on server-provided past attempts (not shown here)
    }
    return list;
  }

  Widget _buildTopCards() {
    int completed = _summary?['completed_exams'] ?? 0;
    int warnings = _summary?['warnings'] ?? 0;
    int? accuracy = _summary?['accuracy'];
    String upcoming = _summary?['upcoming'] ?? 'No upcoming exams';

    Widget card(String title, String value, IconData icon, Color color) {
      return Expanded(
        child: Container(
          padding: const EdgeInsets.all(14),
          margin: const EdgeInsets.symmetric(horizontal: 6),
          decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.95),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 12)]),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(icon, color: color),
              const SizedBox(width: 8),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w600))
            ]),
            const SizedBox(height: 8),
            Text(value,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ]),
        ),
      );
    }

    return Row(children: [
      card("Completed", "$completed", Icons.check_circle_outline, Colors.green),
      card(
          "Warnings", "$warnings", Icons.warning_amber_outlined, Colors.orange),
      card("Accuracy", accuracy != null ? "$accuracy%" : "N/A",
          Icons.show_chart, Colors.deepPurple)
    ]);
  }

  Widget _buildAnnouncements() {
    if (_announcements.isEmpty) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
          color: const Color(0xFFFDECEA),
          borderRadius: BorderRadius.circular(10)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text("Announcements",
            style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ..._announcements.map((a) => Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Text("• ${a['message']}")))
      ]),
    );
  }

  Widget _buildSearchAndTabs() {
    return Column(
      children: [
        TextField(
          decoration: InputDecoration(
              hintText: "Search exams...",
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: const Color(0xFFF3EFFF),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none)),
          onChanged: (v) => setState(() => _search = v),
        ),
        const SizedBox(height: 8),
        Row(children: [
          ChoiceChip(
              label: const Text("Upcoming"),
              selected: _tab == 'upcoming',
              onSelected: (_) => setState(() => _tab = 'upcoming')),
          const SizedBox(width: 8),
          ChoiceChip(
              label: const Text("Completed"),
              selected: _tab == 'completed',
              onSelected: (_) => setState(() => _tab = 'completed')),
          const SizedBox(width: 8),
          ChoiceChip(
              label: const Text("Missed"),
              selected: _tab == 'missed',
              onSelected: (_) => setState(() => _tab = 'missed')),
        ]),
      ],
    );
  }

  Widget _buildExamList() {
    List list = _filteredExams();
    if (list.isEmpty)
      return const Center(child: Text("No exams found in this category."));
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: list.length,
      itemBuilder: (context, idx) {
        var exam = list[idx];
        String name = exam['name'] ?? 'Untitled';
        String time = exam['exam_datetime'] ?? exam['time'] ?? 'TBD';
        return Card(
          margin: const EdgeInsets.symmetric(vertical: 8),
          child: ListTile(
            title: Text(name),
            subtitle: Text(time),
            trailing: ElevatedButton(
                onPressed: () => _startExam(exam['id'], name),
                child: const Text("Start")),
          ),
        );
      },
    );
  }

  Widget _buildCalendar() {
    if (_calendar.isEmpty) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text("Upcoming Schedule",
          style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      ..._calendar
          .map((e) => ListTile(
              leading: const Icon(Icons.event),
              title: Text(e['name']),
              subtitle: Text(e['exam_datetime'] ?? 'TBD')))
          .toList()
    ]);
  }

  Widget _buildLeaderboard() {
    if (_leaderboard.isEmpty) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text("Leaderboard (Top)",
          style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      ..._leaderboard
          .take(5)
          .map((p) => ListTile(
              leading: CircleAvatar(
                  child: Text(((_leaderboard.indexOf(p)) + 1).toString())),
              title: Text(p['name']),
              subtitle: Text(
                  "Accuracy: ${p['accuracy'] ?? 'N/A'}% — Warnings: ${p['warnings']}")))
          .toList()
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(children: [
          UserAccountsDrawerHeader(
              accountName: Text(widget.studentName),
              accountEmail: Text(widget.studentId),
              currentAccountPicture:
                  const CircleAvatar(child: Icon(Icons.person))),
          ListTile(
              leading: const Icon(Icons.event_note),
              title: const Text("Scheduled Exams"),
              onTap: () => Navigator.pop(context)),
          ListTile(
              leading: const Icon(Icons.bar_chart),
              title: const Text("Student Performance"),
              onTap: () => Navigator.pop(context)),
          ListTile(
              leading: const Icon(Icons.assignment_turned_in),
              title: const Text("Results"),
              onTap: () => Navigator.pop(context)),
          ListTile(
              leading: const Icon(Icons.logout),
              title: const Text("Logout"),
              onTap: () {
                globals.globalInstitution = "";
                globals.globalUserId = "";
                globals.globalUserName = "";
                globals.globalUserRole = "";
                Navigator.pop(context);
                Navigator.pop(context);
              }),
        ]),
      ),
      appBar: AppBar(
          title: const Text("Student Dashboard"),
          backgroundColor: const Color(0xFF673AB7)),
      body: RefreshIndicator(
        onRefresh: _refreshAll,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Align(
                alignment: Alignment.centerLeft,
                child: Text("Welcome, ${widget.studentName}!",
                    style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF512DA8)))),
            const SizedBox(height: 12),
            _buildTopCards(),
            const SizedBox(height: 12),
            _buildAnnouncements(),
            const SizedBox(height: 12),
            _buildSearchAndTabs(),
            const SizedBox(height: 12),
            _buildCalendar(),
            const SizedBox(height: 12),
            _buildExamList(),
            const SizedBox(height: 12),
            _buildLeaderboard(),
            const SizedBox(height: 20),
          ]),
        ),
      ),
    );
  }
}
