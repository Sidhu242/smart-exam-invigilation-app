// lib/exam_page.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'dart:typed_data';
import 'package:camera/camera.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'global.dart' as globals;
import 'package:smart_exam_app/widgets/exam_timer.dart'; // keep if exists; otherwise remove or implement simple timer widget

class ExamPage extends StatefulWidget {
  final String examId;
  final String examName;
  final String studentId;

  const ExamPage(
      {Key? key,
      required this.examId,
      required this.examName,
      required this.studentId})
      : super(key: key);

  @override
  State<ExamPage> createState() => _ExamPageState();
}

class _ExamPageState extends State<ExamPage> {
  bool _isLoading = true;
  List _questions = [];
  int _currentQuestionIndex = 0;
  String? _selectedMcqOption;
  final _essayController = TextEditingController();
  Map<String, String> _answers = {};
  CameraController? _cameraController;
  bool _isCameraInitialized = false;
  Timer? _frameSendingTimer;
  bool _isSendingFrame = false;

  @override
  void initState() {
    super.initState();
    _initializePage();
  }

  Future<void> _initializePage() async {
    if (mounted) setState(() => _isLoading = true);
    await _initializeCamera();
    await _fetchQuestions();
    if (mounted) {
      setState(() {
        _isLoading = false;
        _loadCurrentQuestionState();
      });
    }
  }

  Future<void> _initializeCamera() async {
    try {
      bool hasPermission = true;
      if (!kIsWeb) {
        var cameraStatus = await Permission.camera.request();
        hasPermission = cameraStatus.isGranted;
      }
      if (hasPermission && mounted) {
        final cameras = await availableCameras();
        if (cameras.isNotEmpty && mounted) {
          _cameraController = CameraController(
              cameras.first, ResolutionPreset.medium,
              enableAudio: false);
          await _cameraController!.initialize();
          if (mounted) {
            setState(() => _isCameraInitialized = true);
            _startFrameSendingTimer();
          }
        } else {
          debugPrint("No cameras found");
        }
      } else {
        debugPrint("Camera permission denied");
      }
    } catch (e) {
      debugPrint("Error initializing camera: $e");
    }
  }

  Future<void> _fetchQuestions() async {
    try {
      var url = Uri.parse('${globals.SERVER}/get_questions/${widget.examId}');
      var response = await http.get(url);
      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        setState(() => _questions = data['questions'] ?? []);
      } else {
        debugPrint('Server error fetching questions: ${response.body}');
      }
    } catch (e) {
      debugPrint('Could not connect to server to fetch questions: $e');
    }
  }

  @override
  void dispose() {
    _frameSendingTimer?.cancel();
    _cameraController?.dispose();
    _essayController.dispose();
    super.dispose();
  }

  void _startFrameSendingTimer() {
    _frameSendingTimer = Timer.periodic(
        const Duration(seconds: 5), (timer) => _captureAndSendFrame());
  }

  Future<void> _captureAndSendFrame() async {
    if (!_isCameraInitialized ||
        _cameraController == null ||
        !_cameraController!.value.isInitialized ||
        _isSendingFrame) return;
    if (mounted) setState(() => _isSendingFrame = true);
    try {
      final XFile imageFile = await _cameraController!.takePicture();
      final Uint8List imageBytes = await imageFile.readAsBytes();
      final String base64Image = base64Encode(imageBytes);

      var url = Uri.parse('${globals.SERVER}/check_frame');
      await http.post(url,
          headers: {'Content-Type': 'application/json; charset=UTF-8'},
          body: jsonEncode({
            'student_id': widget.studentId,
            'exam_id': widget.examId,
            'image_data': base64Image
          }));
    } catch (e) {
      debugPrint("Error capturing or sending frame: $e");
    } finally {
      if (mounted) setState(() => _isSendingFrame = false);
    }
  }

  void _onTimerEnd() => _saveAndSubmitExam();

  Future<void> _saveAndSubmitExam() async {
    await _saveCurrentAnswer();
    _frameSendingTimer?.cancel();
    if (Navigator.canPop(context)) Navigator.pop(context);
    if (mounted)
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Exam submitted successfully!')));
  }

  Future<void> _saveCurrentAnswer() async {
    if (_questions.isEmpty) return;
    final currentQuestion = _questions[_currentQuestionIndex];
    final questionId = currentQuestion['id'];
    String? answerText;
    if (currentQuestion['question_type'] == 'mcq')
      answerText = _selectedMcqOption;
    else if (currentQuestion['question_type'] == 'essay')
      answerText = _essayController.text;

    if (answerText == null || answerText.isEmpty) return;
    _answers[questionId] = answerText;
    try {
      var url = Uri.parse('${globals.SERVER}/submit_answer');
      await http.post(url,
          headers: {'Content-Type': 'application/json; charset=UTF-8'},
          body: jsonEncode({
            'student_id': widget.studentId,
            'exam_id': widget.examId,
            'question_id': questionId,
            'answer_text': answerText
          }));
    } catch (e) {
      debugPrint("Error saving answer: $e");
    }
  }

  void _loadCurrentQuestionState() {
    if (_questions.isEmpty) return;
    final currentQuestion = _questions[_currentQuestionIndex];
    _selectedMcqOption = null;
    _essayController.text = '';
    String? saved = _answers[currentQuestion['id']];
    if (saved != null) {
      if (currentQuestion['question_type'] == 'mcq')
        _selectedMcqOption = saved;
      else
        _essayController.text = saved;
    }
  }

  Future<void> _nextQuestion() async {
    await _saveCurrentAnswer();
    if (_currentQuestionIndex < _questions.length - 1) {
      setState(() {
        _currentQuestionIndex++;
        _loadCurrentQuestionState();
      });
    } else {
      _saveAndSubmitExam();
    }
  }

  Widget _buildQuestionBody() {
    if (_questions.isEmpty)
      return const Center(
          child: Text('No questions found or still loading...'));
    var q = _questions[_currentQuestionIndex];
    String questionText = q['question_text'] ?? 'No question text';
    String type = q['question_type'];
    List<String> options = [];
    if (type == 'mcq' && q['options'] != null)
      options = List<String>.from(q['options'] as List);

    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Question ${_currentQuestionIndex + 1}/${_questions.length}',
              style: TextStyle(fontSize: 18, color: Colors.grey[700])),
          const SizedBox(height: 10),
          Text(questionText,
              style:
                  const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          if (type == 'mcq')
            ...options
                .map((option) => RadioListTile<String>(
                    title: Text(option),
                    value: option,
                    groupValue: _selectedMcqOption,
                    onChanged: (v) => setState(() => _selectedMcqOption = v)))
                .toList(),
          if (type == 'essay')
            TextField(
                controller: _essayController,
                maxLines: 10,
                decoration: const InputDecoration(
                    hintText: 'Type your answer here...',
                    border: OutlineInputBorder())),
          const SizedBox(height: 20),
          Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey, width: 2)),
              width: 120,
              height: 160,
              child: _isCameraInitialized &&
                      _cameraController != null &&
                      _cameraController!.value.isInitialized
                  ? CameraPreview(_cameraController!)
                  : const Center(child: Text('Initializing Camera...'))),
          const SizedBox(height: 20),
          Center(
              child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 50, vertical: 15)),
                  onPressed: _nextQuestion,
                  child: Text(
                      _currentQuestionIndex == _questions.length - 1
                          ? 'Submit'
                          : 'Next',
                      style: const TextStyle(fontSize: 18)))),
          const SizedBox(height: 20),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text(widget.examName), actions: [
          if (!_isLoading)
            Padding(
                padding: const EdgeInsets.all(8),
                child: Text('Timer', style: TextStyle(color: Colors.white)))
        ]),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : _buildQuestionBody());
  }
}
