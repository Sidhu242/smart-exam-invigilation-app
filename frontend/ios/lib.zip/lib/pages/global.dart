library smart_exam.globals;

String globalInstitution = "";
String globalUserId = "";
String globalUserName = "";
String globalUserRole = "";

const String SERVER = "http://localhost:5000";
