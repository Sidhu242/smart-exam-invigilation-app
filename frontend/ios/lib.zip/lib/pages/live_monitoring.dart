import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';

class LiveMonitoringPage extends StatefulWidget {
  final String examId; // <-- NOW dynamic
  final String institution; // <-- New (for future expansions)

  const LiveMonitoringPage({
    Key? key,
    required this.examId,
    required this.institution,
  }) : super(key: key);

  @override
  State<LiveMonitoringPage> createState() => _LiveMonitoringPageState();
}

class _LiveMonitoringPageState extends State<LiveMonitoringPage> {
  List _warnings = [];
  Timer? _pollingTimer;
  bool _isLoading = true;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _fetchWarnings();

    _pollingTimer = Timer.periodic(
      const Duration(seconds: 4),
      (_) => _fetchWarnings(),
    );
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    super.dispose();
  }

  Future<void> _fetchWarnings() async {
    var url = Uri.parse("http://localhost:5000/get_warnings/${widget.examId}");

    try {
      var response = await http.get(url).timeout(const Duration(seconds: 4));

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);

        setState(() {
          _warnings = data['warnings'];
          _isLoading = false;
          _errorMessage = '';
        });
      } else {
        setState(() {
          _isLoading = false;
          _errorMessage =
              jsonDecode(response.body)['message'] ?? "Unknown server error.";
        });
      }
    } on TimeoutException {
      setState(() {
        _isLoading = false;
        _errorMessage = "Server timeout. Please check your connection.";
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = "Server connection failed.";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F0FA),
      appBar: AppBar(
        title: Text(
          "Live Monitoring – ${widget.examId}",
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        backgroundColor: const Color(0xFF673AB7),
        elevation: 0,
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(
                color: Color(0xFF673AB7),
              ),
            )
          : _errorMessage.isNotEmpty && _warnings.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Text(
                      _errorMessage,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.red,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                )
              : _warnings.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.verified_user,
                              size: 60, color: Colors.green[500]),
                          const SizedBox(height: 16),
                          const Text(
                            "No warnings.\nStudents look safe!",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 18,
                              color: Color(0xFF311B92),
                              fontWeight: FontWeight.w600,
                            ),
                          )
                        ],
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: _fetchWarnings,
                      child: ListView.builder(
                        itemCount: _warnings.length,
                        padding: const EdgeInsets.all(14),
                        itemBuilder: (context, index) {
                          var w = _warnings[index];

                          return Container(
                            margin: const EdgeInsets.only(bottom: 14),
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: Colors.orange.withOpacity(0.5),
                                width: 1.4,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  blurRadius: 14,
                                  offset: const Offset(0, 5),
                                  color: Colors.orange.withOpacity(0.2),
                                ),
                              ],
                            ),
                            child: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(10),
                                  decoration: const BoxDecoration(
                                    color: Color(0xFFFFF3E0),
                                    shape: BoxShape.circle,
                                  ),
                                  child: const Icon(
                                    Icons.warning_amber_rounded,
                                    size: 28,
                                    color: Colors.orange,
                                  ),
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Student: ${w['student_id']}",
                                        style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Color(0xFF311B92),
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        w['message'] ?? "No message",
                                        style: const TextStyle(fontSize: 15),
                                      ),
                                    ],
                                  ),
                                ),
                                Text(
                                  w['timestamp'] != null
                                      ? w['timestamp'].substring(11, 19)
                                      : "--:--",
                                  style: TextStyle(
                                      color: Colors.grey[700], fontSize: 12),
                                )
                              ],
                            ),
                          );
                        },
                      ),
                    ),
    );
  }
}
