// lib/add_question_page.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'global.dart' as globals;

enum QuestionType { mcq, essay }

class AddQuestionPage extends StatefulWidget {
  final String examId;
  final String examName;

  const AddQuestionPage(
      {Key? key, required this.examId, required this.examName})
      : super(key: key);

  @override
  State<AddQuestionPage> createState() => _AddQuestionPageState();
}

class _AddQuestionPageState extends State<AddQuestionPage> {
  final _formKey = GlobalKey<FormState>();
  final _questionIdController = TextEditingController();
  final _questionController = TextEditingController();
  final _option1Controller = TextEditingController();
  final _option2Controller = TextEditingController();
  final _option3Controller = TextEditingController();
  final _option4Controller = TextEditingController();

  QuestionType _selectedType = QuestionType.mcq;
  String? _correctAnswer;
  String _message = '';

  @override
  void dispose() {
    _questionIdController.dispose();
    _questionController.dispose();
    _option1Controller.dispose();
    _option2Controller.dispose();
    _option3Controller.dispose();
    _option4Controller.dispose();
    super.dispose();
  }

  Future<void> _addQuestion() async {
    if (_formKey.currentState?.validate() != true) return;

    Map<String, dynamic> requestBody = {
      'id': _questionIdController.text.trim(),
      'exam_id': widget.examId,
      'question_text': _questionController.text.trim(),
      'question_type': _selectedType.name
    };

    if (_selectedType == QuestionType.mcq) {
      if (_correctAnswer == null) {
        setState(() => _message = 'Select correct answer');
        return;
      }
      List<String> options = [
        _option1Controller.text.trim(),
        _option2Controller.text.trim(),
        _option3Controller.text.trim(),
        _option4Controller.text.trim()
      ];
      requestBody['options'] = options;
      requestBody['correct_answer'] = _correctAnswer;
    }

    var url = Uri.parse('${globals.SERVER}/add_question');
    try {
      var response = await http.post(url,
          headers: {'Content-Type': 'application/json; charset=UTF-8'},
          body: jsonEncode(requestBody));
      var data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['status'] == 'success') {
        setState(() {
          _message =
              'Question added successfully. Add another or Publish exam.';
          _formKey.currentState?.reset();
          _questionIdController.clear();
          _questionController.clear();
          _option1Controller.clear();
          _option2Controller.clear();
          _option3Controller.clear();
          _option4Controller.clear();
          _correctAnswer = null;
        });
      } else {
        setState(() => _message = data['message'] ?? 'Error adding question');
      }
    } catch (e) {
      setState(() => _message = 'Error connecting to server.');
    }
  }

  // Publish exam - teacher action that marks exam as published so students can start
  Future<void> _publishExam() async {
    var url = Uri.parse('${globals.SERVER}/publish_exam');
    try {
      var response = await http.post(url,
          headers: {'Content-Type': 'application/json; charset=UTF-8'},
          body: jsonEncode({'exam_id': widget.examId}));
      var data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['status'] == 'success') {
        setState(() => _message = 'Exam published successfully.');
      } else {
        setState(() => _message = data['message'] ?? 'Error publishing exam');
      }
    } catch (e) {
      setState(() => _message = 'Error connecting to server.');
    }
  }

  Widget _buildMcqFields() {
    return Column(children: [
      TextFormField(
          controller: _option1Controller,
          decoration: const InputDecoration(labelText: 'Option 1 (Required)'),
          validator: (v) => v == null || v.isEmpty ? 'Required' : null,
          onChanged: (_) => setState(() {})),
      const SizedBox(height: 12),
      TextFormField(
          controller: _option2Controller,
          decoration: const InputDecoration(labelText: 'Option 2 (Required)'),
          validator: (v) => v == null || v.isEmpty ? 'Required' : null,
          onChanged: (_) => setState(() {})),
      const SizedBox(height: 12),
      TextFormField(
          controller: _option3Controller,
          decoration: const InputDecoration(labelText: 'Option 3 (Required)'),
          validator: (v) => v == null || v.isEmpty ? 'Required' : null,
          onChanged: (_) => setState(() {})),
      const SizedBox(height: 12),
      TextFormField(
          controller: _option4Controller,
          decoration: const InputDecoration(labelText: 'Option 4 (Required)'),
          validator: (v) => v == null || v.isEmpty ? 'Required' : null,
          onChanged: (_) => setState(() {})),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(
        value: _correctAnswer,
        hint: const Text('Select Correct Answer'),
        items: [
          _option1Controller.text.isNotEmpty
              ? DropdownMenuItem(
                  value: _option1Controller.text,
                  child: Text(_option1Controller.text))
              : null,
          _option2Controller.text.isNotEmpty
              ? DropdownMenuItem(
                  value: _option2Controller.text,
                  child: Text(_option2Controller.text))
              : null,
          _option3Controller.text.isNotEmpty
              ? DropdownMenuItem(
                  value: _option3Controller.text,
                  child: Text(_option3Controller.text))
              : null,
          _option4Controller.text.isNotEmpty
              ? DropdownMenuItem(
                  value: _option4Controller.text,
                  child: Text(_option4Controller.text))
              : null,
        ].whereType<DropdownMenuItem<String>>().toList(),
        onChanged: (v) => setState(() => _correctAnswer = v),
        validator: (v) => v == null ? 'Please select an answer' : null,
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text('Add Questions to ${widget.examName}'),
          backgroundColor: const Color(0xFF673AB7)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('Exam ID: ${widget.examId}',
                style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            DropdownButtonFormField<QuestionType>(
              value: _selectedType,
              decoration: const InputDecoration(labelText: 'Question Type'),
              items: const [
                DropdownMenuItem(
                    value: QuestionType.mcq,
                    child: Text('Multiple Choice (MCQ)')),
                DropdownMenuItem(
                    value: QuestionType.essay,
                    child: Text('Essay / Written Answer')),
              ],
              onChanged: (QuestionType? v) =>
                  setState(() => _selectedType = v ?? QuestionType.mcq),
            ),
            const SizedBox(height: 12),
            TextFormField(
                controller: _questionIdController,
                decoration: const InputDecoration(
                    labelText: 'Question ID (e.g., e3q1)'),
                validator: (v) => v == null || v.isEmpty ? 'Required' : null),
            const SizedBox(height: 12),
            TextFormField(
                controller: _questionController,
                decoration: const InputDecoration(labelText: 'Question Text'),
                validator: (v) => v == null || v.isEmpty ? 'Required' : null,
                maxLines: _selectedType == QuestionType.essay ? 5 : 1),
            const SizedBox(height: 12),
            if (_selectedType == QuestionType.mcq) _buildMcqFields(),
            const SizedBox(height: 18),
            ElevatedButton(
                onPressed: _addQuestion,
                child: const Text('Add Question'),
                style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14))),
            const SizedBox(height: 12),
            ElevatedButton(
                onPressed: _publishExam,
                child: const Text('Publish Exam (Make live)'),
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    padding: const EdgeInsets.symmetric(vertical: 14))),
            const SizedBox(height: 12),
            if (_message.isNotEmpty)
              Text(_message,
                  style: TextStyle(
                      color: _message.contains('success')
                          ? Colors.green
                          : Colors.red)),
          ]),
        ),
      ),
    );
  }
}
